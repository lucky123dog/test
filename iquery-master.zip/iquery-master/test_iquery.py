#!/usr/bin/env python

"""Tests for iqeury."""

import os
import unittest


class TicketsTestCase(unittest.TestCase):
    pass
