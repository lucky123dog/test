Module Contributors
------------------

- `protream <https://github.com/protream>`_ : train/show/movie/hospital
- `bonfy <https://github.com/bonfy>`_: lottery
